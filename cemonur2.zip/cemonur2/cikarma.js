function cikar() {
	sonuc.innerHTML = sayi1.value - sayi2.value ;
}