function topla() {
	sonuc.innerHTML = parseInt(sayi1.value) + parseInt(sayi2.value) ;
}